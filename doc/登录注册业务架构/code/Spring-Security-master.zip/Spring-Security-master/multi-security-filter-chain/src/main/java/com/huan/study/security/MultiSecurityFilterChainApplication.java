package com.huan.study.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiSecurityFilterChainApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultiSecurityFilterChainApplication.class, args);
    }
}
