<template>
  <div class="support-author">
    <p class="abstract">觉得文章不错，点个赞吧！</p>
    <div class="btn support-btn">点赞支持</div>
  </div>
</template>

<script>
</script>

<style lang="scss" scoped>
.support-author {
  text-align: center;
  margin-top: 50px;
  height: 80px;

  .abstract {
    padding: 0 30px;
    margin-bottom: 20px;
    min-height: 24px;
    font-size: 17px;
    font-weight: 700;
    color: #969696;
  }

  .support-btn {
    font-size: 16px;
    color: #fff;
    background-color: #ea6f5a;
    border-radius: 20px;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    white-space: nowrap;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857;
  }
}
</style>
