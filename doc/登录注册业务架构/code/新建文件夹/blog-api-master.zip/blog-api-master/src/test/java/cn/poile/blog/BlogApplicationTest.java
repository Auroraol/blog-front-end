package cn.poile.blog;

import lombok.extern.log4j.Log4j2;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author: yaohw
 * @create: 2019-10-23 18:47
 **/
//@RunWith(SpringRunner.class)
//@SpringBootTest
@Log4j2
public class BlogApplicationTest {

    @Test
    public void test() {

    }

}
