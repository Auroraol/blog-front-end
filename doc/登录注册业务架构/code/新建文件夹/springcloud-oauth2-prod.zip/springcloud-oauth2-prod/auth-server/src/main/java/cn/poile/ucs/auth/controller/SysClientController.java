package cn.poile.ucs.auth.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yaohw
 * @since 2020-09-07
 */
@RestController
@RequestMapping("/sysClient")
public class SysClientController extends BaseController {

}
