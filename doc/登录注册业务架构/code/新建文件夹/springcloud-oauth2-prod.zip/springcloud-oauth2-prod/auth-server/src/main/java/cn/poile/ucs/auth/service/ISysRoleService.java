package cn.poile.ucs.auth.service;

import cn.poile.ucs.auth.entity.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author yaohw
 * @since 2020-09-07
 */
public interface ISysRoleService extends IService<SysRole> {

}
