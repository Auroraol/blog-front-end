package cn.poile.ucs.auth.mapper;

import cn.poile.ucs.auth.entity.SysRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色表 Mapper 接口
 * </p>
 *
 * @author yaohw
 * @since 2020-09-07
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {

}
