package cn.poile.ucs.auth.service;

import cn.poile.ucs.auth.entity.SysAuthority;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 权限表 服务类
 * </p>
 *
 * @author yaohw
 * @since 2020-09-07
 */
public interface ISysAuthorityService extends IService<SysAuthority> {

}
