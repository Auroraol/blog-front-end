package cn.poile.ucs.auth.service;

import cn.poile.ucs.auth.entity.SysClient;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author yaohw
 * @since 2020-09-07
 */
public interface ISysClientService extends IService<SysClient> {

}
