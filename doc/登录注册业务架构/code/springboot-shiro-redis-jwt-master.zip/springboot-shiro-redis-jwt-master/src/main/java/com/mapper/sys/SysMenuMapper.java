package com.mapper.sys;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.sys.SysMenu;

public interface SysMenuMapper extends BaseMapper<SysMenu> {
}
