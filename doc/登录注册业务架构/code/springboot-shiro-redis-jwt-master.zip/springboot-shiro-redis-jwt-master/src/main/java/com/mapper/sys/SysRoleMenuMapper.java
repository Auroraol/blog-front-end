package com.mapper.sys;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.sys.SysRoleMenu;
import org.springframework.stereotype.Repository;

@Repository
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {
}
