package com.mapper.sys;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.sys.SysRole;

public interface SysRoleMapper extends BaseMapper<SysRole> {
}
