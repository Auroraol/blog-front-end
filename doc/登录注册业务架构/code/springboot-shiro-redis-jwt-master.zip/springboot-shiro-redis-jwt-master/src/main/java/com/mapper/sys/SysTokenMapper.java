package com.mapper.sys;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.sys.SysToken;
import org.springframework.stereotype.Repository;

@Repository
public interface SysTokenMapper extends BaseMapper<SysToken> {
}
