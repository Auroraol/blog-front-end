package com.mapper.sys;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.sys.SysLog;

public interface SysLogMapper extends BaseMapper<SysLog> {
}
